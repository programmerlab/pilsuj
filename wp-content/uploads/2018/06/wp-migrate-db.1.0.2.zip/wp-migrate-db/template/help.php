<div class="help-tab content-tab">
	<?php $this->template_part( array( 'wordpress_org_support', 'licence_info', 'debug_info', 'videos' ) ); ?>
</div> <!-- end .help-tab -->
